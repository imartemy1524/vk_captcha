from .solver import VkCaptchaSolver

__version__ = '1.0'


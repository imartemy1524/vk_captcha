from .solver import VkCaptchaSolver

__version__ = '2.0'

